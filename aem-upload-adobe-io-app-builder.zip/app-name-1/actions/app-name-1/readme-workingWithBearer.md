/*
 * <license header>
 */

/**
 * This is a sample action showcasing how to create a cloud event and publish to I/O Events
 *
 * Note:
 * You might want to disable authentication and authorization checks against Adobe Identity Management System for a generic action. In that case:
 *   - Remove the require-adobe-auth annotation for this action in the manifest.yml of your application
 *   - Remove the Authorization header from the array passed in checkMissingRequestInputs
 *   - The two steps above imply that every client knowing the URL to this deployed action will be able to invoke it without any authentication and authorization checks against Adobe Identity Management System
 *   - Make sure to validate these changes against your security requirements before deploying the action
 */

const { Core, Events } = require("@adobe/aio-sdk");
const DirectBinary = require("@adobe/aem-upload");
const uuid = require("uuid");
const { CloudEvent } = require("cloudevents");
const {
  FileSystemUploadOptions,
  FileSystemUpload,
} = require("@adobe/aem-upload");
const {
  errorResponse,
  getBearerToken,
  stringParameters,
  checkMissingRequestInputs,
} = require("../utils");

// main function that will be executed by Adobe I/O Runtime
async function main(params) {
  // create a Logger
  const logger = Core.Logger("main", { level: params.LOG_LEVEL || "info" });
  // URL to the folder in AEM where assets will be uploaded. Folder
  // must already exist.
  const targetUrl =
    "https://author-p139726-e1433618.adobeaemcloud.com/content/dam/asset";

  const credentials =
    "eyJhbGciOiJSUzI1NiIsIng1dSI6Imltc19uYTEta2V5LWF0LTEuY2VyIiwia2lkIjoiaW1zX25hMS1rZXktYXQtMSIsIml0dCI6ImF0In0.eyJpZCI6IjE3MzI3NzIyNjIzOTJfMzE0NjQzMDItNmViOC00NWRmLThhM2QtMjllNGY3NzBmMTM5X3V3MiIsInR5cGUiOiJhY2Nlc3NfdG9rZW4iLCJjbGllbnRfaWQiOiJleGNfYXBwIiwidXNlcl9pZCI6IkEwRDM0NzdFNjM4RUNGOEQwQTQ5NUZCQ0AzZmJkMzEzMzYzOGI3ZGFjNDk1ZTRhLmUiLCJzdGF0ZSI6IntcInNlc3Npb25cIjpcImh0dHBzOi8vaW1zLW5hMS5hZG9iZWxvZ2luLmNvbS9pbXMvc2Vzc2lvbi92MS9OR0V6TWpOa04ySXROak5pWVMwME1XWmtMV0pqTldNdE9UQTVNMlV3WVRnNE9HRm1MUzB3TWpjME1VUTNNVFkyTmpJMFFqQkZNRUUwT1RWRE5VVkFOVFJtTVRVeFptUTJNalEyWm1NNVlqUTVOV1UyTkM1bFwifSIsImFzIjoiaW1zLW5hMSIsImFhX2lkIjoiQzMyQTcyMzg2MURENEEyRjBBNDk1QzcwQGFkb2JlLmNvbSIsImN0cCI6MCwiZmciOiJZN1VaRENRUFhQUDc0SFcySE9RVjJYQUFWND09PT09PSIsInNpZCI6IjE3MzI2NjgxNzI5MzVfNjc1MzY1NjgtNjc5ZS00OTBkLThhNjQtZWI1MjFjZmJjNWJlX3V3MiIsIm1vaSI6IjNiMDQ3NjE3IiwicGJhIjoiT1JHLE1lZFNlY05vRVYsTG93U2VjIiwiZXhwaXJlc19pbiI6Ijg2NDAwMDAwIiwiY3JlYXRlZF9hdCI6IjE3MzI3NzIyNjIzOTIiLCJzY29wZSI6ImFiLm1hbmFnZSxhY2NvdW50X2NsdXN0ZXIucmVhZCxhZGRpdGlvbmFsX2luZm8sYWRkaXRpb25hbF9pbmZvLmpvYl9mdW5jdGlvbixhZGRpdGlvbmFsX2luZm8ucHJvamVjdGVkUHJvZHVjdENvbnRleHQsYWRkaXRpb25hbF9pbmZvLnJvbGVzLEFkb2JlSUQsYWRvYmVpby5hcHByZWdpc3RyeS5yZWFkLGFkb2JlaW9fYXBpLGF1ZGllbmNlbWFuYWdlcl9hcGksY3JlYXRpdmVfY2xvdWQsbXBzLG9wZW5pZCxvcmcucmVhZCxwcHMucmVhZCxyZWFkX29yZ2FuaXphdGlvbnMscmVhZF9wYyxyZWFkX3BjLmFjcCxyZWFkX3BjLmRtYV90YXJ0YW4sc2Vzc2lvbiJ9.O-harloseoPRW3po7vhBDLpJCWHXjdxQ2Ul10DzxqOTiqS_HZ-1bOXNsiaWiV2OmlHGcMzkAlM0Q1hjm_mGAi5GfnFNfo6C_t6UZLUJFo5nHfbQBJnsDmh6oAce7sNvPA7HCBG_cWZn8hapQSxTx5HR7D8_rLciRcdDBNhEtDXYpa66lgjr3mPdWipKp78Sji55pWytVB3SodL99GebssIagHnqm6S4TB4vXx36grru-XXwtEZ0ssvuUipYAY9D2CUeYDtjZsYFik5jJI1Qe5sAObhOv3ScC5i8tb8CkFnzzS9OqjiTX7oAAfUHOmRp-sHSsME06yDfBV5bmRsy9hA";
  try {
    // 'info' is the default level if not set
    logger.info("Calling the main action rupesh");
    const options = new FileSystemUploadOptions()
      .withUrl(targetUrl)
      .withHttpOptions({
        headers: {
          Authorization: `Bearer ${credentials}`,
        },
      });

    // upload a single asset and all assets in a given folder
    const fileUpload = new FileSystemUpload();
    await fileUpload.upload(options, [
      "/Users/rupeshk/Documents/projects/sio/app-name-1/image1.png",
    ]);
    return "success";
  } catch (error) {
    return "failure";
  }
}

function createCloudEvent(providerId, eventCode, payload) {
  let cloudevent = new CloudEvent({
    source: "urn:uuid:" + providerId,
    type: eventCode,
    datacontenttype: "application/json",
    data: payload,
    id: uuid.v4(),
  });
  return cloudevent;
}
exports.main = main;
