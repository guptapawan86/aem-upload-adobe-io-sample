"use strict";
const { Core } = require("@adobe/aio-sdk");
const { FileSystemUploadOptions, FileSystemUpload } = require("@adobe/aem-upload");
const fs = require("fs");

// main function that will be executed by Adobe I/O Runtime
async function main(params) {
  // create a Logger
  const logger = Core.Logger("main", { level: params.LOG_LEVEL || "info" });
  // URL to the folder in AEM where assets will be uploaded. Folder must already exist.
  const targetUrl =
    "https://author-p139726-e1433618.adobeaemcloud.com/content/dam/asset";

  const exchange = require("/Users/rupeshk/Documents/projects/sio/app-name-1/index_for_clientlib");
  const jsonfile =
    "/Users/rupeshk/Documents/projects/sio/app-name-1/aemcs-service-credentials.json";
  const config = JSON.parse(fs.readFileSync(jsonfile, "utf8"));

  // Exchange token and then upload file
  return exchange(config)
    .then((accessToken) => {
      const token = accessToken.access_token;
      logger.info("Access token successfully retrieved.");

      // Set up file upload options
      const options = new FileSystemUploadOptions()
        .withUrl(targetUrl)
        .withHttpOptions({
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

      // Perform the file upload
      const fileUpload = new FileSystemUpload();
      return fileUpload.upload(options, [
        "/Users/rupeshk/Documents/projects/sio/app-name-1/image2.png",
      ]);
    })
    .then(() => {
      logger.info("File upload completed successfully.");
      return { statusCode: 200, body: "File upload successful." };
    })
    .catch((error) => {
      logger.error("Error occurred:", error);
      return {
        statusCode: 500,
        body: `File upload failed: ${error.message}`,
      };
    });
}

exports.main = main;
