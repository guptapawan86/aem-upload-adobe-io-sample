/*
 * <license header>
 */

/**
 * This is a sample action showcasing how to create a cloud event and publish to I/O Events
 *
 * Note:
 * You might want to disable authentication and authorization checks against Adobe Identity Management System for a generic action. In that case:
 *   - Remove the require-adobe-auth annotation for this action in the manifest.yml of your application
 *   - Remove the Authorization header from the array passed in checkMissingRequestInputs
 *   - The two steps above imply that every client knowing the URL to this deployed action will be able to invoke it without any authentication and authorization checks against Adobe Identity Management System
 *   - Make sure to validate these changes against your security requirements before deploying the action
 */

const { Core, Events } = require("@adobe/aio-sdk");
const DirectBinary = require("@adobe/aem-upload");
const uuid = require("uuid");
const { CloudEvent } = require("cloudevents");
const {
  FileSystemUploadOptions,
  FileSystemUpload,
} = require("@adobe/aem-upload");
const {
  errorResponse,
  getBearerToken,
  stringParameters,
  checkMissingRequestInputs,
} = require("../utils");

// main function that will be executed by Adobe I/O Runtime
async function main(params) {
  // create a Logger
  const logger = Core.Logger("main", { level: params.LOG_LEVEL || "info" });
  // URL to the folder in AEM where assets will be uploaded. Folder
  // must already exist.
  const targetUrl =
    "https://author-p139726-e1433618.adobeaemcloud.com/content/dam/asset";

  const credentials = Buffer.from("test-user:admin").toString("base64");
  try {
    // 'info' is the default level if not set
    logger.info("Calling the main action rupesh");
    const options = new FileSystemUploadOptions()
      .withUrl(targetUrl)
      .withHttpOptions({
        headers: {
          Authorization: `Basic ${credentials}`,
        },
      });

    // upload a single asset and all assets in a given folder
    const fileUpload = new FileSystemUpload();
    await fileUpload.upload(options, [
      "/Users/rupeshk/Documents/projects/sio/app-name-1/image.png",
    ]);
    return "success";
  } catch (error) {
    return "failure";
  }
}

function createCloudEvent(providerId, eventCode, payload) {
  let cloudevent = new CloudEvent({
    source: "urn:uuid:" + providerId,
    type: eventCode,
    datacontenttype: "application/json",
    data: payload,
    id: uuid.v4(),
  });
  return cloudevent;
}
exports.main = main;
