async function getAccessToken() {
  const url = "https://ims-na1.adobelogin.com/ims/token/v3";
  const clientId = "<client_id>";
  const clientSecret = "<client_secret>";
  const params = new URLSearchParams();
  params.append("client_id", clientId);
  params.append("client_secret", clientSecret);
  params.append("grant_type", "client_credentials");
  params.append("scope", "<scopes>");
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params,
    });
    if (!response.ok) {
      throw new Error("Failed to get access token");
    }
    const responseData = await response.json();
    return responseData.access_token;
  } catch (error) {
    console.error("Error getting access token:", error);
    throw error;
  }
}
